/**
 * Created by song on 16/11/16.
 */
var PokerType ={

       error:0,
      danpai:1,
     duipai:2,
     sanzhang:3,
      sandaiyi:4,
    danshun:5,
    shuangshun:6,
    sanshun:7,
     feiji:8,
     sidaier:9,
     zhadan:10,
    huojian:11,
     sandaier:13,
     feijicb:14,
     dirH:0,
     dirV:1
};