/**
 * Created by song on 16/11/16.
 */
  var KEY_MUSIC ="key_music_ddz";
var KEY_VIBRATOR ="key_vibrator_ddz";
var KEY_WIN ="key_win";
var KEY_LOSE ="key_lose";
var KEY_SCORE ="key_score";


var KEY_CARD0 ="key_card0";
var KEY_CARD1 ="key_card1";
var KEY_CARD2 ="key_card2";
var KEY_CARD3 ="key_card3";
var KEY_CARD4 ="key_card4";
var KEY_CARD5 ="key_card5";
var KEY_CARD6 ="key_card6";
var KEY_CARD7 ="key_card7";

var KEY_TASK_DATE ="key_task_date";
var KEY_TASK ="key_task";
var KEY_TASK0_C ="key_task0_C";
var KEY_TASK1_C ="key_task1_C";
var KEY_TASK_TIMES ="key_task_times";
var KEY_TASK_WIN ="key_task_win";

var KEY_NAME ="key_name";

var KEY_COIN ="key_coin";
var KEY_VIP ="key_vip";
var KEY_JPQ ="key_jpq";
var KEY_DOUBLE_SCORE ="key_double_score";