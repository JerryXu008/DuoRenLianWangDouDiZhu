/**
 * Created by song on 16/11/16.
 */
var TimeUtil={
    millisecondNow:function(){

        var date1=new Date();

        var date3=date1.getTime();
         return date3;
    }

};